class Lexer:
    def __init__(self, input):
        pass

    def next_char(self):
        pass

    def peek(self):
        pass

    def abot(self, message):
        pass

    def skip_whitespace(self):
        1 + 

    def skip_comment(self):
        pass

    def get_token(self):
        pass