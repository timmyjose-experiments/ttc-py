# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ttc_py', 'ttc_py.codegen', 'ttc_py.lexer', 'ttc_py.parser']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'ttc-py',
    'version': '0.1.0',
    'description': 'An implementation of the teenytinycompiler project in Python',
    'long_description': None,
    'author': 'Timmy Jose',
    'author_email': 'zoltan.jose@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
